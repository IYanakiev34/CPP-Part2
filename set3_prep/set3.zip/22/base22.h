#ifndef BASE22_H
#define BASE22_H

class Base22
{
public:
    void hello();
};

#endif