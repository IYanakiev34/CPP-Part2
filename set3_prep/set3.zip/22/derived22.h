#ifndef DERIVED22_H
#define DERIVED22_H

#include "base22.h"

class Derived22 : public Base22
{
public:
    void hello();
};

#endif