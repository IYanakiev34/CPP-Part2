#include "ex22.ih"

void Base22::hello()
{
    std::cout << "Hello from base class\n";
}