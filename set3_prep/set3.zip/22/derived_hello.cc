#include "ex22.ih"

void Derived22::hello()
{
    std::cout << "Hello from derived class\n";
}