#include "strings.ih"

Strings::Strings() : Strings(10)
{
}