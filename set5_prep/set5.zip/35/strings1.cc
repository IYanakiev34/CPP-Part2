#include "strings.ih"

Strings::Strings(std::size_t size) : Strings(size, std::string{})
{
}