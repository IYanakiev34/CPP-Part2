#include "FileFinder.ih"

FileFinder *FileFinder::s_instance = nullptr;