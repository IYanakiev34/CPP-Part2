#include "FileFinder.ih"

FileFinder::FileFinder()
{
}