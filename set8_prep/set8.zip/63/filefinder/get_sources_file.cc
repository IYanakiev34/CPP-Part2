#include "FileFinder.ih"

std::vector<std::string> FileFinder::getSourcesFromFile(std::string const &fileName)
{
    std::vector<std::string> sourceFiles;

    // get filenames from file
    // call helper to find source
    // return set
    // throw error if cannot find all files

    return sourceFiles;
}