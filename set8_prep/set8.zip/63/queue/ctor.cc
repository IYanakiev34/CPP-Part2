#include "BlockQueue.ih"

BlockingQueue::BlockingQueue()
    : b_finished(false)
{
}