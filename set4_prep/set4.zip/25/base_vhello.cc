#include "base.h"

void Base::vHello(std::ostream &out)
{
    out << "Hello from Base\n";
}