#include "26.ih"

void Base::vHello(std::ostream &out)
{
    std::cout << "Hello from base class\n";
}
