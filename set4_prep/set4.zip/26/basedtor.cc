#include "26.ih"

Base::~Base()
{
    std::cout << "Base destructor called\n";
}