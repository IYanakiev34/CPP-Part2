#include "26.ih"

void Base::hello(std::ostream &out)
{
    vHello(out);
}