#include "26.ih"

void Derived::vHello(std::ostream &out)
{
    out << d_name << "\n";
}