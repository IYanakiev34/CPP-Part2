#include "26.ih"

Derived::Derived() : d_name("Hello from derived")
{
}