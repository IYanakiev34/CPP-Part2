#include "26.ih"

Derived::~Derived()
{
    std::cout << "Derived destrucotr called\n";
}