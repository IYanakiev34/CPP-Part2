#include "fork.ih"

Fork::~Fork()
{
}