#include "fork.ih"

Fork::~Fork() = default;