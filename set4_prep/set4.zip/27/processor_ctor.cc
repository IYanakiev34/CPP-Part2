#include "27.ih"

Processor::Processor()
{
    d_Msg = Msg::DEBUG;
}