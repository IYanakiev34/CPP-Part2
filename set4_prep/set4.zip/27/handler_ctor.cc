#include "27.ih"

Handler::Handler()
{
    d_Msg = Msg::ALERT;
}