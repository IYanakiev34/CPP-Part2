#ifndef BASIC_H
#define BASIC_H

class Basic
{
public:
    Basic();
    Basic(int val);
    virtual ~Basic() = default;
};

#endif