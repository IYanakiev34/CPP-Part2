#ifndef DERIVED1_H
#define DERIVED1_H

#include "basic.h"

class Deriv1 : virtual public Basic
{
public:
    Deriv1();
};

#endif