#include "29.ih"

Deriv1::Deriv1()
{
    std::cout << "Derived 1 constructor called\n";
}