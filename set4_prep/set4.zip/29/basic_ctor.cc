#include "29.ih"

Basic::Basic()
{
    std::cout << "Basic concstructor called\n";
}