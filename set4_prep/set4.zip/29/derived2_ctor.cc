#include "29.ih"

Deriv2::Deriv2()
{
    std::cout << "Derived2 constructor called\n";
}