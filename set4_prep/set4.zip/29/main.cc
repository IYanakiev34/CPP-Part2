#include "main.ih"

int main(int argc, char **argv)
{
    Multi ml;

    // Output:
    // Basic constructor called with value: 10
    // Derived 1 constructor called
    // Derived2 constructor called
    // 0x7ffe53715310 (This the print statement of the cast in Multi
    // it is some address in memory of the object)
    // Multi constructor called
}