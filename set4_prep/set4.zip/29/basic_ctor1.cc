#include "29.ih"

Basic::Basic(int val)
{
    std::cout << "Basic constructor called with value: " << val << "\n";
}