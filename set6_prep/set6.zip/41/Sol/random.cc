#include "Random.ih"

Random::Random(unsigned low, unsigned high) : d_Dis(low, high)
{
}
