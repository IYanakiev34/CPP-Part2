#include "FillUnique.h"

void FillUnique::storeValue(std::vector<int> &vec, int val)
{
    vec.push_back(val);
}