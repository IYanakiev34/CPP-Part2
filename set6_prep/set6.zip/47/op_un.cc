#include "iota_wrapper.h"

IotaWrapper::operator unsigned()
{
    return d_value;
}