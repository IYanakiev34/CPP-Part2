#include "main.ih"

int main()
{
    std::vector<size_t> vs{ 1, 2, 2, 3, 4, 4, 4, 5 };
    std::cout << multiples(vs) << " multiples were found\n";
}
