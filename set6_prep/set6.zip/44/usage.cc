#include "main.ih"

void usage()
{
    char const info[] = R"(You must specify the filename
        from which to read the student information)";

    std::cout << info << "\n";
}